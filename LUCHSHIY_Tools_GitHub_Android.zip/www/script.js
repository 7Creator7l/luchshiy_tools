// ========================================
// LUCHSHIY TOOLS
// SCRIPT.JS — BLOCK 1
// APP CORE + STATE + DOM
// ========================================

"use strict";

// ========================================
// APP STATE
// ========================================

const state = {
  currentPage: "home",
  currentTool: null,
  activeCategory: "all",

  favorites: JSON.parse(
    localStorage.getItem("luchshiyFavorites") || "[]"
  ),

  recent: JSON.parse(
    localStorage.getItem("luchshiyRecent") || "[]"
  ),

  timer: {
    seconds: 25 * 60,
    minutes: 25,
    running: false,
    interval: null
  },

  stopwatch: {
    time: 0,
    running: false,
    interval: null,
    startedAt: 0
  }
};

// ========================================
// DOM HELPERS
// ========================================

const $ = (selector) =>
  document.querySelector(selector);

const $$ = (selector) =>
  document.querySelectorAll(selector);

// ========================================
// MAIN ELEMENTS
// ========================================

const toolsGrid =
  $("#toolsGrid");

const searchInput =
  $("#searchInput");

const clearSearch =
  $("#clearSearch");

const emptyState =
  $("#emptyState");

const toolsCount =
  $("#toolsCount");

const recentTools =
  $("#recentTools");

const quickEmpty =
  $("#quickEmpty");

const favoriteGrid =
  $("#favoriteGrid");

const favoriteEmpty =
  $("#favoriteEmpty");

const favoritesPage =
  $("#favoritesPage");

const settingsPage =
  $("#settingsPage");

// ========================================
// MODALS
// ========================================

const toolModal =
  $("#toolModal");

const modalContent =
  $("#modalContent");

const modalTitle =
  $("#modalTitle");

const modalClose =
  $("#modalClose");

const modalBack =
  $("#modalBack");

const modalOverlay =
  $("#modalOverlay");

const settingsModal =
  $("#settingsModal");

const settingsBtn =
  $("#settingsBtn");

const settingsClose =
  $("#settingsClose");

const settingsOverlay =
  $("#settingsOverlay");

// ========================================
// TOAST
// ========================================

const toast =
  $("#toast");

const toastText =
  $("#toastText");

let toastTimer = null;

// ========================================
// TOOL DATABASE
// ========================================

const tools = {

  calculator: {
    title: "Калькулятор",
    icon: "🧮",
    category: "math",
    template: "calculatorTemplate"
  },

  timer: {
    title: "Focus Timer",
    icon: "⏱️",
    category: "time",
    template: "timerTemplate"
  },

  stopwatch: {
    title: "Секундомер",
    icon: "⏲️",
    category: "time",
    template: "stopwatchTemplate"
  },

  words: {
    title: "Счётчик слов",
    icon: "Aa",
    category: "text",
    template: "wordsTemplate"
  },

  converter: {
    title: "Конвертер",
    icon: "📏",
    category: "other",
    template: "converterTemplate"
  },

  random: {
    title: "Случайное число",
    icon: "🎲",
    category: "other",
    template: "randomTemplate"
  },

  password: {
    title: "Генератор паролей",
    icon: "🔐",
    category: "other",
    template: "passwordTemplate"
  },

  qr: {
    title: "QR генератор",
    icon: "▦",
    category: "other",
    template: "qrTemplate"
  },

  percent: {
    title: "Проценты",
    icon: "%",
    category: "math",
    template: "percentTemplate"
  },

  age: {
    title: "Возраст",
    icon: "🎂",
    category: "other",
    template: "ageTemplate"
  },

  date: {
    title: "Калькулятор даты",
    icon: "📅",
    category: "other",
    template: "dateTemplate"
  },

  bmi: {
    title: "Индекс тела",
    icon: "📊",
    category: "other",
    template: "bmiTemplate"
  },

  case: {
    title: "Регистр текста",
    icon: "Aa",
    category: "text",
    template: "caseTemplate"
  },

  cleaner: {
    title: "Очистка текста",
    icon: "🧹",
    category: "text",
    template: "cleanerTemplate"
  },

  study: {
    title: "Планировщик учёбы",
    icon: "📖",
    category: "study",
    template: "studyTemplate"
  }
};

// ========================================
// STORAGE
// ========================================

function saveFavorites() {
  localStorage.setItem(
    "luchshiyFavorites",
    JSON.stringify(state.favorites)
  );
}

function saveRecent() {
  localStorage.setItem(
    "luchshiyRecent",
    JSON.stringify(state.recent)
  );
}

// ========================================
// TOAST
// ========================================

function showToast(message) {
  if (!toast || !toastText) return;

  toastText.textContent = message;

  toast.classList.add("show");

  clearTimeout(toastTimer);

  toastTimer = setTimeout(() => {
    toast.classList.remove("show");
  }, 2200);
}

// ========================================
// FAVORITES
// ========================================

function isFavorite(toolId) {
  return state.favorites.includes(toolId);
}

function toggleFavorite(toolId) {

  if (isFavorite(toolId)) {

    state.favorites =
      state.favorites.filter(
        (id) => id !== toolId
      );

    showToast(
      "Удалено из избранного"
    );

  } else {

    state.favorites.push(toolId);

    showToast(
      "Добавлено в избранное"
    );
  }

  saveFavorites();

  updateFavoriteButtons();
  renderFavorites();
}
// ========================================
// LUCHSHIY TOOLS
// SCRIPT.JS — BLOCK 2
// TOOLS + SEARCH + CATEGORIES
// ========================================

// ========================================
// RENDER TOOL CARDS
// ========================================

function renderToolCards() {

  if (!toolsGrid) return;

  toolsGrid.innerHTML = "";

  Object.entries(tools).forEach(
    ([toolId, tool]) => {

      const card =
        document.createElement("article");

      card.className = "tool-card";

      card.dataset.tool = toolId;
      card.dataset.category = tool.category;

      card.innerHTML = `
        <button
          class="favorite-btn ${isFavorite(toolId) ? "active" : ""}"
          data-favorite="${toolId}"
          aria-label="Добавить в избранное"
        >
          ${isFavorite(toolId) ? "★" : "☆"}
        </button>

        <div class="tool-icon">
          ${tool.icon}
        </div>

        <div class="tool-info">
          <h3>${tool.title}</h3>
          <span>
            ${getCategoryName(tool.category)}
          </span>
        </div>

        <button
          class="tool-open"
          data-open-tool="${toolId}"
        >
          Открыть
        </button>
      `;

      toolsGrid.appendChild(card);
    }
  );

  updateToolsCount();
}

// ========================================
// CATEGORY NAMES
// ========================================

function getCategoryName(category) {

  const names = {
    all: "Все инструменты",
    study: "Учёба",
    time: "Время",
    math: "Математика",
    text: "Текст",
    other: "Другое"
  };

  return names[category] || "Инструмент";
}

// ========================================
// FILTER TOOLS
// ========================================

function filterTools() {

  if (!toolsGrid) return;

  const query =
    (searchInput?.value || "")
      .trim()
      .toLowerCase();

  const cards =
    $$(".tool-card");

  let visible = 0;

  cards.forEach(card => {

    const toolId =
      card.dataset.tool;

    const category =
      card.dataset.category;

    const tool =
      tools[toolId];

    if (!tool) return;

    const matchesSearch =
      tool.title
        .toLowerCase()
        .includes(query);

    const matchesCategory =
      state.activeCategory === "all" ||
      category === state.activeCategory;

    const show =
      matchesSearch &&
      matchesCategory;

    card.style.display =
      show ? "" : "none";

    if (show) visible++;
  });

  updateToolsCount(visible);

  if (emptyState) {

    emptyState.classList.toggle(
      "show",
      visible === 0
    );
  }
}

// ========================================
// TOOLS COUNT
// ========================================

function updateToolsCount(count) {

  if (!toolsCount) return;

  if (typeof count === "number") {

    toolsCount.textContent =
      `${count} инструмент${getPlural(count)}`;
    return;
  }

  const total =
    Object.keys(tools).length;

  toolsCount.textContent =
    `${total} инструментов`;
}

// ========================================
// PLURAL
// ========================================

function getPlural(number) {

  if (number % 10 === 1 &&
      number % 100 !== 11) {
    return "";
  }

  if (
    number % 10 >= 2 &&
    number % 10 <= 4 &&
    (number % 100 < 10 ||
     number % 100 >= 20)
  ) {
    return "а";
  }

  return "ов";
}

// ========================================
// FAVORITE BUTTONS
// ========================================

function updateFavoriteButtons() {

  $$("[data-favorite]").forEach(
    button => {

      const toolId =
        button.dataset.favorite;

      const favorite =
        isFavorite(toolId);

      button.classList.toggle(
        "active",
        favorite
      );

      button.textContent =
        favorite ? "★" : "☆";
    }
  );
}

// ========================================
// CATEGORY BUTTONS
// ========================================

function setupCategories() {

  $$(".category-btn").forEach(
    button => {

      button.addEventListener(
        "click",
        () => {

          state.activeCategory =
            button.dataset.category ||
            "all";

          $$(".category-btn")
            .forEach(item => {
              item.classList.toggle(
                "active",
                item === button
              );
            });

          filterTools();
        }
      );
    }
  );
}

// ========================================
// SEARCH
// ========================================

function setupSearch() {

  if (searchInput) {

    searchInput.addEventListener(
      "input",
      () => {

        filterTools();

        if (clearSearch) {
          clearSearch.classList.toggle(
            "show",
            searchInput.value.length > 0
          );
        }
      }
    );
  }

  if (clearSearch) {

    clearSearch.addEventListener(
      "click",
      () => {

        if (searchInput) {
          searchInput.value = "";
          searchInput.focus();
        }

        clearSearch.classList.remove("show");

        filterTools();
      }
    );
  }
}

// ========================================
// TOOL CARD CLICKS
// ========================================

function setupToolClicks() {

  if (!toolsGrid) return;

  toolsGrid.addEventListener(
    "click",
    event => {

      const favoriteButton =
        event.target.closest(
          "[data-favorite]"
        );

      if (favoriteButton) {

        event.stopPropagation();

        toggleFavorite(
          favoriteButton.dataset.favorite
        );

        return;
      }

      const openButton =
        event.target.closest(
          "[data-open-tool]"
        );

      if (openButton) {

        openTool(
          openButton.dataset.openTool
        );

        return;
      }

      const card =
        event.target.closest(".tool-card");

      if (card) {

        openTool(
          card.dataset.tool
        );
      }
    }
  );
}
// ========================================
// LUCHSHIY TOOLS
// SCRIPT.JS — BLOCK 3
// NAVIGATION + FAVORITES + RECENT
// ========================================

// ========================================
// ADD TO RECENT
// ========================================

function addToRecent(toolId) {

  if (!tools[toolId]) return;

  state.recent =
    state.recent.filter(
      id => id !== toolId
    );

  state.recent.unshift(toolId);

  // Храним максимум 6 инструментов
  state.recent =
    state.recent.slice(0, 6);

  saveRecent();

  renderRecent();
}

// ========================================
// RENDER RECENT
// ========================================

function renderRecent() {

  if (!recentTools) return;

  recentTools.innerHTML = "";

  if (state.recent.length === 0) {

    if (quickEmpty) {
      quickEmpty.style.display = "block";
    }

    return;
  }

  if (quickEmpty) {
    quickEmpty.style.display = "none";
  }

  state.recent.forEach(toolId => {

    const tool = tools[toolId];

    if (!tool) return;

    const item =
      document.createElement("button");

    item.className = "recent-item";

    item.dataset.openTool =
      toolId;

    item.innerHTML = `
      <span class="recent-icon">
        ${tool.icon}
      </span>

      <span class="recent-name">
        ${tool.title}
      </span>
    `;

    recentTools.appendChild(item);
  });
}

// ========================================
// RECENT CLICK
// ========================================

function setupRecentClicks() {

  if (!recentTools) return;

  recentTools.addEventListener(
    "click",
    event => {

      const item =
        event.target.closest(
          "[data-open-tool]"
        );

      if (!item) return;

      openTool(
        item.dataset.openTool
      );
    }
  );
}

// ========================================
// RENDER FAVORITES
// ========================================

function renderFavorites() {

  if (!favoriteGrid) return;

  favoriteGrid.innerHTML = "";

  const favoriteTools =
    state.favorites
      .filter(id => tools[id]);

  if (favoriteTools.length === 0) {

    if (favoriteEmpty) {
      favoriteEmpty.style.display =
        "block";
    }

    return;
  }

  if (favoriteEmpty) {
    favoriteEmpty.style.display =
      "none";
  }

  favoriteTools.forEach(toolId => {

    const tool = tools[toolId];

    const card =
      document.createElement("article");

    card.className = "tool-card";

    card.dataset.tool =
      toolId;

    card.innerHTML = `
      <button
        class="favorite-btn active"
        data-favorite="${toolId}"
      >
        ★
      </button>

      <div class="tool-icon">
        ${tool.icon}
      </div>

      <div class="tool-info">
        <h3>${tool.title}</h3>
        <span>
          ${getCategoryName(tool.category)}
        </span>
      </div>

      <button
        class="tool-open"
        data-open-tool="${toolId}"
      >
        Открыть
      </button>
    `;

    favoriteGrid.appendChild(card);
  });
}

// ========================================
// FAVORITE CLICKS
// ========================================

function setupFavoriteClicks() {

  if (!favoriteGrid) return;

  favoriteGrid.addEventListener(
    "click",
    event => {

      const favoriteButton =
        event.target.closest(
          "[data-favorite]"
        );

      if (favoriteButton) {

        toggleFavorite(
          favoriteButton.dataset.favorite
        );

        return;
      }

      const openButton =
        event.target.closest(
          "[data-open-tool]"
        );

      if (openButton) {

        openTool(
          openButton.dataset.openTool
        );
      }
    }
  );
}

// ========================================
// PAGE NAVIGATION
// ========================================

function showPage(pageName) {

  state.currentPage =
    pageName;

  if (toolsGrid) {
    toolsGrid.parentElement
      ?.classList.toggle(
        "hidden",
        pageName !== "home"
      );
  }

  if (favoritesPage) {
    favoritesPage.classList.toggle(
      "active",
      pageName === "favorites"
    );
  }

  if (settingsPage) {
    settingsPage.classList.toggle(
      "active",
      pageName === "settings"
    );
  }

  const homeSections =
    $$(".home-only");

  homeSections.forEach(section => {
    section.style.display =
      pageName === "home"
        ? ""
        : "none";
  });
}

// ========================================
// BOTTOM NAVIGATION
// ========================================

function setupNavigation() {

  $$("[data-page]").forEach(
    button => {

      button.addEventListener(
        "click",
        () => {

          const page =
            button.dataset.page;

          if (!page) return;

          showPage(page);

          $$("[data-page]")
            .forEach(item => {
              item.classList.toggle(
                "active",
                item === button
              );
            });
        }
      );
    }
  );

  if (favoriteGoHome) {

    favoriteGoHome.addEventListener(
      "click",
      () => {
        showPage("home");
      }
    );
  }
}

// ========================================
// TOOL MODAL
// ========================================

function openTool(toolId) {

  const tool = tools[toolId];

  if (!tool ||
      !toolModal ||
      !modalContent) {
    return;
  }

  const template =
    document.getElementById(
      tool.template
    );

  if (!template) {
    showToast(
      "Инструмент временно недоступен"
    );
    return;
  }

  state.currentTool =
    toolId;

  if (modalTitle) {
    modalTitle.textContent =
      tool.title;
  }

  modalContent.innerHTML = "";

  modalContent.appendChild(
    template.content.cloneNode(true)
  );

  toolModal.classList.add("show");

  document.body.classList.add(
    "modal-open"
  );

  addToRecent(toolId);

  initializeTool(toolId);
}

// ========================================
// CLOSE TOOL
// ========================================

function closeTool() {

  if (!toolModal) return;

  toolModal.classList.remove(
    "show"
  );

  document.body.classList.remove(
    "modal-open"
  );

  state.currentTool =
    null;
}

// ========================================
// MODAL BUTTONS
// ========================================

function setupModal() {

  if (modalClose) {
    modalClose.addEventListener(
      "click",
      closeTool
    );
  }

  if (modalBack) {
    modalBack.addEventListener(
      "click",
      closeTool
    );
  }

  if (modalOverlay) {
    modalOverlay.addEventListener(
      "click",
      closeTool
    );
  }

  document.addEventListener(
    "keydown",
    event => {

      if (
        event.key === "Escape" &&
        toolModal?.classList.contains("show")
      ) {
        closeTool();
      }
    }
  );
}
// ========================================
// LUCHSHIY TOOLS
// SCRIPT.JS — BLOCK 4
// CALCULATOR + TIMER + STOPWATCH + TEXT
// ========================================

// ========================================
// INITIALIZE TOOL
// ========================================

function initializeTool(toolId) {

  if (toolId === "calculator") {
    initCalculator();
  }

  if (toolId === "timer") {
    initTimer();
  }

  if (toolId === "stopwatch") {
    initStopwatch();
  }

  if (toolId === "words") {
    initWords();
  }

  if (toolId === "converter") {
    initConverter();
  }

  if (toolId === "random") {
    initRandom();
  }

  if (toolId === "password") {
    initPassword();
  }

  if (toolId === "qr") {
    initQR();
  }

  if (toolId === "percent") {
    initPercent();
  }

  if (toolId === "age") {
    initAge();
  }

  if (toolId === "date") {
    initDate();
  }

  if (toolId === "bmi") {
    initBMI();
  }

  if (toolId === "case") {
    initCase();
  }

  if (toolId === "cleaner") {
    initCleaner();
  }

  if (toolId === "study") {
    initStudy();
  }
}

// ========================================
// CALCULATOR
// ========================================

function initCalculator() {

  const display =
    $("#calculatorDisplay");

  if (!display) return;

  let expression = "";

  $$(".calc-btn").forEach(button => {

    button.addEventListener(
      "click",
      () => {

        const value =
          button.dataset.value;

        if (value === "clear") {
          expression = "";
          display.textContent = "0";
          return;
        }

        if (value === "back") {
          expression =
            expression.slice(0, -1);

          display.textContent =
            expression || "0";

          return;
        }

        if (value === "=") {

          try {

            if (!expression) return;

            const result =
              Function(
                `"use strict"; return (${expression})`
              )();

            if (
              typeof result !== "number" ||
              !Number.isFinite(result)
            ) {
              throw new Error();
            }

            expression =
              String(result);

            display.textContent =
              expression;

          } catch {
            expression = "";
            display.textContent =
              "Ошибка";
          }

          return;
        }

        expression += value;

        display.textContent =
          expression;
      }
    );
  });
}

// ========================================
// TIMER
// ========================================

function initTimer() {

  const display =
    $("#timerDisplay");

  const start =
    $("#timerStart");

  const reset =
    $("#timerReset");

  if (!display) return;

  function updateTimer() {

    const minutes =
      Math.floor(
        state.timer.seconds / 60
      );

    const seconds =
      state.timer.seconds % 60;

    display.textContent =
      `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  }

  $$(".timer-minute").forEach(button => {

    button.addEventListener(
      "click",
      () => {

        if (state.timer.running) return;

        const minutes =
          Number(button.dataset.minutes);

        if (!Number.isFinite(minutes)) return;

        state.timer.minutes =
          minutes;

        state.timer.seconds =
          minutes * 60;

        updateTimer();
      }
    );
  });

  start?.addEventListener(
    "click",
    () => {

      if (state.timer.running) {

        state.timer.running = false;

        clearInterval(
          state.timer.interval
        );

        start.textContent =
          "Продолжить";

        return;
      }

      if (state.timer.seconds <= 0) {
        state.timer.seconds =
          state.timer.minutes * 60;
      }

      state.timer.running = true;

      start.textContent =
        "Пауза";

      state.timer.interval =
        setInterval(() => {

          if (state.timer.seconds > 0) {

            state.timer.seconds--;

            updateTimer();

          } else {

            clearInterval(
              state.timer.interval
            );

            state.timer.running = false;

            start.textContent =
              "Старт";

            showToast(
              "Время вышло!"
            );
          }

        }, 1000);
    }
  );

  reset?.addEventListener(
    "click",
    () => {

      clearInterval(
        state.timer.interval
      );

      state.timer.running = false;

      state.timer.seconds =
        state.timer.minutes * 60;

      start.textContent =
        "Старт";

      updateTimer();
    }
  );

  updateTimer();
}

// ========================================
// STOPWATCH
// ========================================

function initStopwatch() {

  const display =
    $("#stopwatchDisplay");

  const start =
    $("#stopwatchStart");

  const reset =
    $("#stopwatchReset");

  if (!display) return;

  function formatTime(ms) {

    const total =
      Math.floor(ms / 10);

    const minutes =
      Math.floor(total / 6000);

    const seconds =
      Math.floor((total % 6000) / 100);

    const centiseconds =
      total % 100;

    return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}.${String(centiseconds).padStart(2, "0")}`;
  }

  function update() {

    display.textContent =
      formatTime(state.stopwatch.time);
  }

  start?.addEventListener(
    "click",
    () => {

      if (state.stopwatch.running) {

        state.stopwatch.running = false;

        state.stopwatch.time =
          Date.now() -
          state.stopwatch.startedAt;

        clearInterval(
          state.stopwatch.interval
        );

        start.textContent =
          "Продолжить";

        return;
      }

      state.stopwatch.startedAt =
        Date.now() -
        state.stopwatch.time;

      state.stopwatch.running = true;

      start.textContent =
        "Пауза";

      state.stopwatch.interval =
        setInterval(() => {

          state.stopwatch.time =
            Date.now() -
            state.stopwatch.startedAt;

          update();

        }, 10);
    }
  );

  reset?.addEventListener(
    "click",
    () => {

      clearInterval(
        state.stopwatch.interval
      );

      state.stopwatch.time = 0;
      state.stopwatch.running = false;

      start.textContent =
        "Старт";

      update();
    }
  );

  update();
}

// ========================================
// WORD COUNTER
// ========================================

function initWords() {

  const input =
    $("#wordsInput");

  if (!input) return;

  const wordCount =
    $("#wordCount");

  const charCount =
    $("#charCount");

  const charNoSpaceCount =
    $("#charNoSpaceCount");

  const lineCount =
    $("#lineCount");

  function update() {

    const text =
      input.value;

    const words =
      text.trim()
        ? text.trim().split(/\s+/).length
        : 0;

    const chars =
      text.length;

    const noSpaces =
      text.replace(/\s/g, "").length;

    const lines =
      text
        ? text.split(/\r?\n/).length
        : 0;

    if (wordCount)
      wordCount.textContent = words;

    if (charCount)
      charCount.textContent = chars;

    if (charNoSpaceCount)
      charNoSpaceCount.textContent =
        noSpaces;

    if (lineCount)
      lineCount.textContent =
        lines;
  }

  input.addEventListener(
    "input",
    update
  );

  update();
}
// ========================================
// LUCHSHIY TOOLS
// SCRIPT.JS — BLOCK 5
// OTHER TOOLS + SETTINGS + START
// ========================================

// ========================================
// CONVERTER
// ========================================

function initConverter() {

  const input = $("#converterInput");
  const from = $("#converterFrom");
  const to = $("#converterTo");
  const result = $("#converterResult");

  if (!input || !from || !to || !result) return;

  function convert() {

    const value = Number(input.value);

    if (!Number.isFinite(value)) {
      result.textContent = "Введите число";
      return;
    }

    const units = {
      m: 1,
      cm: 0.01,
      km: 1000,
      ft: 0.3048,
      in: 0.0254
    };

    const meters = value * units[from.value];

    const answer =
      meters / units[to.value];

    result.textContent =
      `${answer.toFixed(4)} ${to.value}`;
  }

  input.addEventListener("input", convert);
  from.addEventListener("change", convert);
  to.addEventListener("change", convert);
}

// ========================================
// RANDOM NUMBER
// ========================================

function initRandom() {

  const min = $("#randomMin");
  const max = $("#randomMax");
  const result = $("#randomResult");
  const button = $("#randomGenerate");

  if (!min || !max || !result || !button) return;

  button.addEventListener("click", () => {

    const a = Number(min.value);
    const b = Number(max.value);

    if (!Number.isFinite(a) ||
        !Number.isFinite(b) ||
        a > b) {

      result.textContent = "Ошибка";
      return;
    }

    const number =
      Math.floor(
        Math.random() * (b - a + 1)
      ) + a;

    result.textContent = number;
  });
}

// ========================================
// PASSWORD GENERATOR
// ========================================

function initPassword() {

  const length = $("#passwordLength");
  const result = $("#passwordResult");
  const generate = $("#passwordGenerate");
  const copy = $("#passwordCopy");

  if (!length || !result || !generate) return;

  function generatePassword() {

    const chars =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";

    let password = "";

    const size =
      Math.max(
        4,
        Math.min(64, Number(length.value) || 12)
      );

    for (let i = 0; i < size; i++) {
      password +=
        chars[Math.floor(Math.random() * chars.length)];
    }

    result.value = password;
  }

  generate.addEventListener(
    "click",
    generatePassword
  );

  copy?.addEventListener(
    "click",
    async () => {

      if (!result.value) return;

      try {
        await navigator.clipboard.writeText(
          result.value
        );

        showToast("Пароль скопирован");
      } catch {
        showToast("Не удалось скопировать");
      }
    }
  );

  generatePassword();
}

// ========================================
// QR GENERATOR
// ========================================

function initQR() {

  const input = $("#qrInput");
  const button = $("#qrGenerate");
  const result = $("#qrResult");

  if (!input || !button || !result) return;

  button.addEventListener("click", () => {

    const text = input.value.trim();

    if (!text) {
      result.innerHTML =
        "<p>Введите текст или ссылку</p>";
      return;
    }

    const encoded =
      encodeURIComponent(text);

    result.innerHTML = `
      <img
        src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encoded}"
        alt="QR код"
      >
    `;
  });
}

// ========================================
// PERCENT
// ========================================

function initPercent() {

  const number = $("#percentNumber");
  const percent = $("#percentValue");
  const button = $("#percentCalculate");
  const result = $("#percentResult");

  if (!number || !percent || !button || !result) return;

  button.addEventListener("click", () => {

    const n = Number(number.value);
    const p = Number(percent.value);

    if (!Number.isFinite(n) ||
        !Number.isFinite(p)) {

      result.textContent = "Введите значения";
      return;
    }

    result.textContent =
      `${p}% от ${n} = ${(n * p / 100).toFixed(2)}`;
  });
}

// ========================================
// AGE
// ========================================

function initAge() {

  const input = $("#ageDate");
  const button = $("#ageCalculate");
  const result = $("#ageResult");

  if (!input || !button || !result) return;

  button.addEventListener("click", () => {

    const birth = new Date(input.value);

    if (Number.isNaN(birth.getTime())) {
      result.textContent = "Выберите дату";
      return;
    }

    const today = new Date();

    let age =
      today.getFullYear() -
      birth.getFullYear();

    const month =
      today.getMonth() -
      birth.getMonth();

    if (
      month < 0 ||
      (month === 0 &&
       today.getDate() < birth.getDate())
    ) {
      age--;
    }

    result.textContent =
      `Возраст: ${Math.max(0, age)} лет`;
  });
}

// ========================================
// DATE DIFFERENCE
// ========================================

function initDate() {

  const first = $("#dateFirst");
  const second = $("#dateSecond");
  const button = $("#dateCalculate");
  const result = $("#dateResult");

  if (!first || !second || !button || !result) return;

  button.addEventListener("click", () => {

    const a = new Date(first.value);
    const b = new Date(second.value);

    if (
      Number.isNaN(a.getTime()) ||
      Number.isNaN(b.getTime())
    ) {
      result.textContent = "Выберите обе даты";
      return;
    }

    const days =
      Math.round(
        Math.abs(b - a) /
        (1000 * 60 * 60 * 24)
      );

    result.textContent =
      `Разница: ${days} дней`;
  });
}

// ========================================
// BODY INDEX
// ========================================

function initBMI() {

  const height = $("#bmiHeight");
  const weight = $("#bmiWeight");
  const button = $("#bmiCalculate");
  const result = $("#bmiResult");

  if (!height || !weight || !button || !result) return;

  button.addEventListener("click", () => {

    const h = Number(height.value) / 100;
    const w = Number(weight.value);

    if (
      !Number.isFinite(h) ||
      !Number.isFinite(w) ||
      h <= 0 ||
      w <= 0
    ) {
      result.textContent = "Введите данные";
      return;
    }

    const bmi =
      w / (h * h);

    result.textContent =
      `Индекс: ${bmi.toFixed(1)}`;
  });
}

// ========================================
// TEXT CASE
// ========================================

function initCase() {

  const input = $("#caseInput");
  const result = $("#caseResult");

  if (!input || !result) return;

  $$(".case-btn").forEach(button => {

    button.addEventListener("click", () => {

      const type =
        button.dataset.case;

      const text = input.value;

      if (type === "upper") {
        result.value =
          text.toUpperCase();
      }

      if (type === "lower") {
        result.value =
          text.toLowerCase();
      }

      if (type === "capitalize") {
        result.value =
          text.replace(
            /(^|\s)\S/g,
            letter => letter.toUpperCase()
          );
      }
    });
  });
}

// ========================================
// TEXT CLEANER
// ========================================

function initCleaner() {

  const input = $("#cleanerInput");
  const button = $("#cleanerRun");
  const copy = $("#cleanerCopy");
  const result = $("#cleanerResult");

  if (!input || !button || !result) return;

  button.addEventListener("click", () => {

    result.value =
      input.value
        .replace(/[ \t]+/g, " ")
        .replace(/\n\s+/g, "\n")
        .trim();

    showToast("Текст очищен");
  });

  copy?.addEventListener("click", async () => {

    if (!result.value) return;

    try {
      await navigator.clipboard.writeText(
        result.value
      );

      showToast("Текст скопирован");
    } catch {
      showToast("Не удалось скопировать");
    }
  });
}

// ========================================
// STUDY PLANNER
// ========================================

function initStudy() {

  const subject = $("#studySubject");
  const task = $("#studyTask");
  const time = $("#studyTime");
  const add = $("#studyAdd");
  const list = $("#studyList");

  if (!subject || !task || !add || !list) return;

  add.addEventListener("click", () => {

    if (!subject.value.trim() ||
        !task.value.trim()) {

      showToast("Заполни предмет и задачу");
      return;
    }

    const item =
      document.createElement("div");

    item.className = "study-item";

    item.innerHTML = `
      <strong>${subject.value}</strong>
      <span>${task.value}</span>
      <small>${time?.value || 0} мин.</small>
    `;

    list.appendChild(item);

    subject.value = "";
    task.value = "";

    showToast("Задача добавлена");
  });
}

// ========================================
// SETTINGS
// ========================================

function setupSettings() {

  settingsBtn?.addEventListener(
    "click",
    () => {
      settingsModal?.classList.add("show");
    }
  );

  settingsClose?.addEventListener(
    "click",
    () => {
      settingsModal?.classList.remove("show");
    }
  );

  settingsOverlay?.addEventListener(
    "click",
    () => {
      settingsModal?.classList.remove("show");
    }
  );

  $$(".theme-option").forEach(button => {

    button.addEventListener("click", () => {

      const theme =
        button.dataset.theme;

      document.body.classList.remove(
        "theme-light",
        "theme-dark"
      );

      document.body.classList.add(
        `theme-${theme}`
      );

      localStorage.setItem(
        "luchshiyTheme",
        theme
      );
    });
  });

  $("#animationsToggle")?.addEventListener(
    "change",
    event => {

      document.body.classList.toggle(
        "no-animations",
        !event.target.checked
      );

      localStorage.setItem(
        "luchshiyAnimations",
        event.target.checked
      );
    }
  );

  $("#clearRecent")?.addEventListener(
    "click",
    () => {

      state.recent = [];

      saveRecent();
      renderRecent();

      showToast("История очищена");
    }
  );

  $("#clearFavorites")?.addEventListener(
    "click",
    () => {

      state.favorites = [];

      saveFavorites();

      renderToolCards();
      renderFavorites();

      showToast("Избранное очищено");
    }
  );

  $("#resetApp")?.addEventListener(
    "click",
    () => {

      localStorage.removeItem(
        "luchshiyFavorites"
      );

      localStorage.removeItem(
        "luchshiyRecent"
      );

      localStorage.removeItem(
        "luchshiyTheme"
      );

      localStorage.removeItem(
        "luchshiyAnimations"
      );

      location.reload();
    }
  );
}

// ========================================
// LOAD SETTINGS
// ========================================

function loadSettings() {

  const theme =
    localStorage.getItem(
      "luchshiyTheme"
    );

  if (theme) {
    document.body.classList.add(
      `theme-${theme}`
    );
  }

  const animations =
    localStorage.getItem(
      "luchshiyAnimations"
    );

  if (animations === "false") {

    document.body.classList.add(
      "no-animations"
    );

    const toggle =
      $("#animationsToggle");

    if (toggle) {
      toggle.checked = false;
    }
  }
}

// ========================================
// APP START
// ========================================

function initApp() {

  loadSettings();

  renderToolCards();
  renderRecent();
  renderFavorites();

  setupCategories();
  setupSearch();
  setupToolClicks();
  setupRecentClicks();
  setupFavoriteClicks();

  setupNavigation();
  setupModal();
  setupSettings();

  showPage("home");

  console.log(
    "LUCHSHIY TOOLS запущен"
  );
}

// ========================================
// START
// ========================================

if (
  document.readyState === "loading"
) {

  document.addEventListener(
    "DOMContentLoaded",
    initApp
  );

} else {

  initApp();
}