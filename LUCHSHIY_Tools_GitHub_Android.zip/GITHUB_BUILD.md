# Как получить APK и AAB

1. Создай новый GitHub repository.
2. Загрузи содержимое этой папки в repository.
3. Открой вкладку **Actions**.
4. Выбери **Build Android**.
5. Нажми **Run workflow**.
6. После завершения открой результат workflow и скачай artifact `LUCHSHIY-Tools-Android`.

В artifact будут APK и AAB.

Для Google Play нужен release AAB с подписью. Не загружай keystore и пароли в обычные файлы репозитория.
