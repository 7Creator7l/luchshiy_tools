# LUCHSHIY Tools — Android

Это Android-обёртка для готового HTML/CSS/JavaScript приложения.

## Что внутри
- `www/` — готовый сайт приложения
- `capacitor.config.ts` — настройки Capacitor
- `package.json` — зависимости
- `.github/workflows/android.yml` — автоматическая сборка APK и AAB через GitHub Actions

## Сборка локально
```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
./gradlew assembleRelease
./gradlew bundleRelease
```

## Сборка через GitHub
После загрузки проекта в GitHub открой:
**Actions → Build Android → Run workflow**.

Workflow соберёт:
- debug APK
- release APK
- release AAB

Важно: для публикации в Google Play нужен подписанный release AAB. В этом проекте подпись не хранится в GitHub и должна быть добавлена позже через GitHub Secrets/keystore.
