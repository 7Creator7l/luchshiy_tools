import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.luchshiy.tools',
  appName: 'LUCHSHIY Tools',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
